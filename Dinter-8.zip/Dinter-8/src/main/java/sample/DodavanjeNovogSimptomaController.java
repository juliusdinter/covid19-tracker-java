package main.java.sample;

import hr.java.covidportal.main.Glavna;
import hr.java.covidportal.model.Simptom;
import hr.java.covidportal.model.Zupanija;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.CheckBox;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.List;

public class DodavanjeNovogSimptomaController {
        @FXML
        private TextField nazivSimptoma;

        @FXML
        private RadioButton vrijednostRIJETKO;

        @FXML
        private RadioButton vrijednostSREDNJE;

        @FXML
        private RadioButton vrijednostCESTO;

        Path tekst = Path.of("dat/simptomi.txt");

        @FXML
        public void zapisiuDatoteku(){

            String naziv = nazivSimptoma.getText();

            String simptom=null;

            if(vrijednostRIJETKO.isSelected()){
                simptom = "RIJETKO";
            }
            if(vrijednostSREDNJE.isSelected()){
                simptom = "SREDNJE";
            }
            if(vrijednostCESTO.isSelected()){
                simptom = "ČESTO";
            }

            List<Simptom> listaSimptoma = Glavna.getSimptoms();

            Long id = listaSimptoma.get(listaSimptoma.size()-1).getId() + 1;

            String ID = id.toString();

            if(naziv!=null && simptom!=null){
                try{
                    Files.writeString(tekst, ID + '\n', StandardOpenOption.APPEND);
                    Files.writeString(tekst, naziv + '\n', StandardOpenOption.APPEND);
                    Files.writeString(tekst, simptom + '\n', StandardOpenOption.APPEND);
                }catch(IOException e){
                    e.printStackTrace();
                }
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Zapis u datoteku");
                alert.setHeaderText("Uspješno zapisano!");
                alert.showAndWait();
            }else{
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Zapis u datoteku");
                alert.setHeaderText("Greška u unosu podataka!");
                alert.setContentText("Ponovno unesite podatke!");
                alert.showAndWait();
            }
        }
}
