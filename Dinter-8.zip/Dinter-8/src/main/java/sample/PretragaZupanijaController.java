package main.java.sample;

import hr.java.covidportal.main.Glavna;
import hr.java.covidportal.model.Zupanija;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.Serializable;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

public class PretragaZupanijaController implements Initializable {
    @FXML
    private TextField searchTextField;

    List<Zupanija> zupanijedat = Glavna.getZupanijas();

    @FXML
    private TableView<Zupanija> tablicaZupanija;

    @FXML
    private TableColumn<Zupanija, String> stupacNaziva;

    @FXML
    private TableColumn<Zupanija, Integer> brojStanovnika;

    @FXML
    private TableColumn<Zupanija, Integer> brojZarazenih;

    @FXML
    public void trazi(){
        String trazenaRijec = searchTextField.getText();
        List<Zupanija> filtriranaListaZupanija = zupanijedat.stream()
                .filter(p -> p.getNaziv().toLowerCase().contains(trazenaRijec.toLowerCase()))
                .collect(Collectors.toList());
        tablicaZupanija.setItems(FXCollections.observableList(filtriranaListaZupanija));
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        stupacNaziva.setCellValueFactory(new PropertyValueFactory<Zupanija, String>("naziv"));
        brojStanovnika.setCellValueFactory(new PropertyValueFactory<Zupanija, Integer>("brojStanovnika"));
        brojZarazenih.setCellValueFactory(new PropertyValueFactory<Zupanija, Integer>("brojZarazenih"));
        tablicaZupanija.setItems(FXCollections.observableList(zupanijedat));
    }
}
