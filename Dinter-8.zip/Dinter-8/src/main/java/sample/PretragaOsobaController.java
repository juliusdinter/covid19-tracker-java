package main.java.sample;

import hr.java.covidportal.main.Glavna;
import hr.java.covidportal.model.*;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.security.GeneralSecurityException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

public class PretragaOsobaController implements Initializable {
    List<Osoba> osobedat = new ArrayList<>();
    @FXML
    private TextField traziNazivImena;

    @FXML
    private TextField traziNazivPrezimena;

    @FXML
    private TableView<Osoba> tablicaOsoba;

    @FXML
    private TableColumn<Osoba, String> stupacNaziva;

    @FXML
    private TableColumn<Osoba, String> stupacPrezimena;

    @FXML
    private TableColumn<Osoba, Zupanija> stupacZupanije;

    @FXML
    private TableColumn<Osoba, Long> stupacStarosti;

    @FXML
    private TableColumn<Osoba, Bolest> stupacBolesti;

    @FXML
    private TableColumn<Osoba, Osoba[]> stupacOsoba;


    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        stupacNaziva.setCellValueFactory(new PropertyValueFactory<Osoba, String>("ime"));
        stupacPrezimena.setCellValueFactory(new PropertyValueFactory<Osoba, String>("prezime"));
        stupacZupanije.setCellValueFactory(new PropertyValueFactory<Osoba, Zupanija>("zupanija"));
        stupacStarosti.setCellValueFactory(new PropertyValueFactory<Osoba, Long>("starost"));
        stupacBolesti.setCellValueFactory(new PropertyValueFactory<Osoba, Bolest>("zarazenBolescu"));
        stupacOsoba.setCellValueFactory(new PropertyValueFactory<Osoba, Osoba[]>("kontaktiraneOsobe"));
        List<Bolest> listaBolesti = PretragaBolestiController.getBolests(Glavna.getSimptoms());
        List<Virus> listaVirusi = PretragaVirusaController.getBolests(Glavna.getSimptoms());
        listaBolesti.addAll(listaVirusi);
        osobedat = Glavna.getOsobas(Glavna.getZupanijas(), listaBolesti);
        tablicaOsoba.setItems(FXCollections.observableList(osobedat));
    }

    @FXML
    public void trazi(){
        String trazenaRijec = traziNazivImena.getText();
        String trazenoPrezime = traziNazivPrezimena.getText();
        List<Osoba> filtriranaListaOsoba = osobedat.stream()
                .filter(p -> p.getIme().toLowerCase().contains(trazenaRijec.toLowerCase())
                        && p.getPrezime().toLowerCase().contains(trazenoPrezime.toLowerCase()))
                .collect(Collectors.toList());
        tablicaOsoba.setItems(FXCollections.observableList(filtriranaListaOsoba));
    }


}
