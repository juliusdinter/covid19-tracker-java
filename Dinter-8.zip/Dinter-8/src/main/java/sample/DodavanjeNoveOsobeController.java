package main.java.sample;

import hr.java.covidportal.main.Glavna;
import hr.java.covidportal.model.*;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TextField;

import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

public class DodavanjeNoveOsobeController implements Initializable {
    ObservableList<String> zupanije;
    ObservableList<String> bolesti;
    ObservableList<String> kontakti;
    List<Zupanija> listaZupanija = new ArrayList<>();
    List<Bolest> listaBolesti = new ArrayList<>();
    List<Virus> listaVirusa = new ArrayList<>();
    List<Osoba> listaOsoba = new ArrayList<>();
    List<String> imenaOsoba = new ArrayList<>();
    @FXML
    private TextField ime;

    @FXML
    private TextField prezime;

    @FXML
    private TextField starost;

    @FXML
    private ListView<String> odabirZupanije;

    @FXML
    private ListView<String> odabirBolesti;

    @FXML
    private ListView<String> odabirKontakata;

    Path tekst = Path.of("dat/osobe.txt");

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        listaBolesti = Glavna.getBolests(Glavna.getSimptoms());
        listaVirusa = PretragaVirusaController.getBolests(Glavna.getSimptoms());
        listaBolesti.addAll(listaVirusa);
        listaZupanija = Glavna.getZupanijas();
        listaOsoba = Glavna.getOsobas(Glavna.getZupanijas(), Glavna.getBolests(Glavna.getSimptoms()));
        odabirZupanije.getItems().addAll(listaZupanija.stream().map(Zupanija::getNaziv).collect(Collectors.toList()));
        odabirBolesti.getItems().addAll(listaBolesti.stream().map(Bolest::getNaziv).collect(Collectors.toList()));
        odabirKontakata.getItems().addAll(listaOsoba.stream().map(Osoba::getIme).collect(Collectors.toList()));
        odabirZupanije.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        odabirBolesti.getSelectionModel().setSelectionMode(SelectionMode.SINGLE);
        odabirKontakata.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
    }

    @FXML
    public void zapisiuDatoteku(){
        String imeOsobe = ime.getText();
        String prezimeOsobe = prezime.getText();
        String starostOsobe = starost.getText();
        String odabranaZupanija = "";
        String odabranaBolest = "";
        String odabraniKontakti = "";
        zupanije = odabirZupanije.getSelectionModel().getSelectedItems();
        bolesti = odabirBolesti.getSelectionModel().getSelectedItems();
        kontakti = odabirKontakata.getSelectionModel().getSelectedItems();
        for(Zupanija h : listaZupanija){
            for(String s : zupanije){
                if(s.equals(h.getNaziv())){
                    odabranaZupanija+=h.getId();
                    break;
                }
            }
        }
        for (Bolest bolest : listaBolesti) {
            for (String s : bolesti) {
                if (s.equals(bolest.getNaziv()) && bolest.getIdBolesti()==1) {
                    odabranaBolest += bolest.getId() + ",1";
                }else if(s.equals(bolest.getNaziv()) && bolest.getIdBolesti()==2){
                    odabranaBolest+=bolest.getId() + ",2";
                }
            }
        }

        for(Osoba o : listaOsoba){
            for(String s : kontakti){
                if(s.equals(o.getIme()) && s.equals(kontakti.get(kontakti.size()-1))){
                    odabraniKontakti+=o.getId();
                }else if(s.equals(o.getIme())){
                    odabraniKontakti+=o.getId()+",";
                }
            }
        }

        Long id = listaOsoba.get(listaOsoba.size()-1).getId() + 1;

        String ID = Long.toString(id);

        if(ime==null || prezime==null || starost==null || odabranaZupanija.equals("")
                || odabranaBolest.equals("") || odabraniKontakti.equals("")){
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Zapis u datoteku");
            alert.setHeaderText("Greška u unosu podataka!");
            alert.setContentText("Ponovno unesite podatke!");
            alert.showAndWait();
        }else{
            try{
                Files.writeString(tekst, ID + '\n', StandardOpenOption.APPEND);
                Files.writeString(tekst, imeOsobe + '\n', StandardOpenOption.APPEND);
                Files.writeString(tekst, prezimeOsobe + '\n', StandardOpenOption.APPEND);
                Files.writeString(tekst, starostOsobe + '\n', StandardOpenOption.APPEND);
                Files.writeString(tekst, odabranaZupanija + '\n', StandardOpenOption.APPEND);
                Files.writeString(tekst, odabranaBolest + '\n', StandardOpenOption.APPEND);
                Files.writeString(tekst, odabraniKontakti + '\n', StandardOpenOption.APPEND);
            }catch(IOException e){
                e.printStackTrace();
            }
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Zapis u datoteku");
            alert.setHeaderText("Uspješno zapisano!");
            alert.showAndWait();
        }
    }
}
