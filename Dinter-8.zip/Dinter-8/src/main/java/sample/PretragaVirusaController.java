package main.java.sample;

import hr.java.covidportal.main.Glavna;
import hr.java.covidportal.model.Bolest;
import hr.java.covidportal.model.Simptom;
import hr.java.covidportal.model.Virus;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

public class PretragaVirusaController implements Initializable {
    @FXML
    private TextField traziNaziv;

    public static List<Virus> getBolests(List<Simptom> simptomiList) {
        List<Virus> virusiList = new ArrayList<>();
        File virusi = new File("dat/virusi.txt");
        try(FileReader fileReader = new FileReader(virusi);
            BufferedReader reader = new BufferedReader(fileReader)){
            String procitanaLinija;
            while((procitanaLinija = reader.readLine())!=null){
                int brojacBolesti=0;
                Long id = Long.parseLong(procitanaLinija);
                String naziv = reader.readLine();
                String brojevi = reader.readLine();
                List<Long> idSimptoma = new ArrayList<>();
                for(int i=0;i<brojevi.length();i++){
                    if(brojevi.charAt(i)!=','){
                        int broj=Character.getNumericValue(brojevi.charAt(i));
                        idSimptoma.add( (long) broj);
                        brojacBolesti++;
                    }
                }
                virusiList.add(new Virus(id, naziv, dodaj(idSimptoma, simptomiList)));
            }
        }
        catch (IOException ex){
            ex.printStackTrace();
        }
        return virusiList;
    }
    private static List<Simptom> dodaj(List<Long> idSimptoma, List<Simptom> simptomiList) {
        List<Simptom> simptomiBolesti= new ArrayList<>();
        for(int i=0; i<idSimptoma.size(); i++){
            if(idSimptoma.get(i)!=null){
                for(int j=0;j<simptomiList.size();j++){
                    if(idSimptoma.get(i).equals(simptomiList.get(j).getId())){
                        simptomiBolesti.add(new Simptom(simptomiList.get(j).getId(), simptomiList.get(j).getNaziv(), simptomiList.get(j).getVrijednost()));
                    }
                }
            }
        }
        return simptomiBolesti;
    }

    List<Simptom> simptomiBolesti = Glavna.getSimptoms();

    List<Virus> virusidat = getBolests(simptomiBolesti);

    @FXML
    private TableView<Virus> tablicaBolesti;

    @FXML
    private TableColumn<Virus, String> stupacNaziva;

    @FXML
    private TableColumn<Virus, List<Simptom>> stupacSimptomiVirusa;

    @FXML
    public void trazi(){
        String trazenaRijec = traziNaziv.getText();
        List<Virus> filtriranaListaBolesti = virusidat.stream()
                .filter(p -> p.getNaziv().toLowerCase().contains(trazenaRijec.toLowerCase()))
                .collect(Collectors.toList());
        tablicaBolesti.setItems(FXCollections.observableList(filtriranaListaBolesti));
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        stupacNaziva.setCellValueFactory(new PropertyValueFactory<Virus, String>("naziv"));
        stupacSimptomiVirusa.setCellValueFactory(new PropertyValueFactory<Virus, List<Simptom>>("Simptomi"));
        tablicaBolesti.setItems(FXCollections.observableList(virusidat));
    }
}
