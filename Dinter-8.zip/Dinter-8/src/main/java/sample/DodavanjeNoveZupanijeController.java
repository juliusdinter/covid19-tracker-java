package main.java.sample;

import hr.java.covidportal.main.Glavna;
import hr.java.covidportal.model.Zupanija;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.List;

public class DodavanjeNoveZupanijeController {
    @FXML
    private TextField nazivZupanije;

    @FXML
    private TextField brojStanovnika;

    @FXML
    private TextField brojZarazenih;

    Path tekst = Path.of("dat/zupanije.txt");

    @FXML
    public void zapisiuDatoteku(){

        String naziv = nazivZupanije.getText();

        String brStanovnika = brojStanovnika.getText();

        String brZarazenih = brojZarazenih.getText();

        List<Zupanija> listaZupanija = Glavna.getZupanijas();

        Long id = listaZupanija.get(listaZupanija.size()-1).getId() + 1;

        String ID = id.toString();

        if(naziv!=null && brStanovnika!=null && brZarazenih!=null){
            try{
                Integer numberStanovnika = Integer.parseInt(brStanovnika);
            }catch(NumberFormatException n){
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Zapis u datoteku");
                alert.setHeaderText("Greška u unosu podataka!");
                alert.setContentText("Ponovno unesite podatke!");
                alert.showAndWait();
                return;
            }
            try{
                Integer numberZarazenih = Integer.parseInt(brZarazenih);
            }catch(NumberFormatException n){
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("Zapis u datoteku");
                alert.setHeaderText("Greška u unosu podataka!");
                alert.setContentText("Ponovno unesite podatke!");
                alert.showAndWait();
                return;
            }

            try{
                Files.writeString(tekst, ID + '\n', StandardOpenOption.APPEND);
                Files.writeString(tekst, naziv + '\n', StandardOpenOption.APPEND);
                Files.writeString(tekst, brStanovnika + '\n', StandardOpenOption.APPEND);
                Files.writeString(tekst, brZarazenih+ '\n', StandardOpenOption.APPEND);
            }catch(IOException e){
                e.printStackTrace();
            }
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Zapis u datoteku");
            alert.setHeaderText("Uspješno zapisano!");
            alert.showAndWait();
        }else{
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Zapis u datoteku");
            alert.setHeaderText("Greška u unosu podataka!");
            alert.setContentText("Ponovno unesite podatke!");
            alert.showAndWait();
        }
    }
}
