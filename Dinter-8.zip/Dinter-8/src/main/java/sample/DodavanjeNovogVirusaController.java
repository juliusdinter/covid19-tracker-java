package main.java.sample;

import hr.java.covidportal.main.Glavna;
import hr.java.covidportal.model.Bolest;
import hr.java.covidportal.model.Simptom;
import hr.java.covidportal.model.Virus;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.beans.value.ObservableValue;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.CheckBoxListCell;
import javafx.util.Callback;

import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

public class DodavanjeNovogVirusaController implements Initializable {
    ObservableList<String> simptomiHello;
    List<Simptom> listaSimptoma = new ArrayList<>();
    List<String> naziviSimptoma;
    @FXML
    private TextField nazivBolesti;

    @FXML
    private ListView<String> odabirSimptoma;

    Path tekst = Path.of("dat/virusi.txt");

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        listaSimptoma = Glavna.getSimptoms();
        naziviSimptoma = listaSimptoma.stream().map(Simptom::getNaziv).collect(Collectors.toList());
        odabirSimptoma.getItems().addAll(naziviSimptoma);
        odabirSimptoma.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);

    }

    @FXML
    public void zapisiuDatoteku(){
        String naziv = nazivBolesti.getText();

        String odabraniSimptomi = "";

        simptomiHello = odabirSimptoma.getSelectionModel().getSelectedItems();

        for(Simptom h : listaSimptoma){
            for(String s : simptomiHello){
                if(s.equals(h.getNaziv()) && s.equals(simptomiHello.get(simptomiHello.size()-1))){
                    odabraniSimptomi+=h.getId();
                    break;
                }else if(s.equals(h.getNaziv())){
                    odabraniSimptomi+=h.getId()+",";
                    break;
                }
            }
        }

        List<Virus> listaBolesti = PretragaVirusaController.getBolests(Glavna.getSimptoms());
        Long id = listaBolesti.get(listaBolesti.size()-1).getId() + 1;

        String ID = Long.toString(id);

        if(naziv.equals("") || odabraniSimptomi.equals("")){
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Zapis u datoteku");
            alert.setHeaderText("Greška u unosu podataka!");
            alert.setContentText("Ponovno unesite podatke!");
            alert.showAndWait();
        }else{
            try{
                Files.writeString(tekst, ID + '\n', StandardOpenOption.APPEND);
                Files.writeString(tekst, naziv + '\n', StandardOpenOption.APPEND);
                Files.writeString(tekst, odabraniSimptomi + '\n', StandardOpenOption.APPEND);
            }catch(IOException e){
                e.printStackTrace();
            }
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Zapis u datoteku");
            alert.setHeaderText("Uspješno zapisano!");
            alert.showAndWait();
        }
    }
}
