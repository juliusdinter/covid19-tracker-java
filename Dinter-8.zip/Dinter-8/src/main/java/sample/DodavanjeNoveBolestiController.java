package main.java.sample;

import hr.java.covidportal.main.Glavna;
import hr.java.covidportal.model.Bolest;
import hr.java.covidportal.model.Simptom;
import hr.java.covidportal.model.Virus;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;

import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.util.List;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

public class DodavanjeNoveBolestiController implements Initializable{

    ObservableList<String> simptomiHello;
    List<Simptom> listaSimptoma;
    List<String> naziviSimptoma;
    @FXML
    private TextField nazivBolesti;

    @FXML
    private ListView<String> odabirSimptoma;

    Path tekst = Path.of("dat/bolesti.txt");

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        listaSimptoma = Glavna.getSimptoms();
        naziviSimptoma = listaSimptoma.stream().map(Simptom::getNaziv).collect(Collectors.toList());
        odabirSimptoma.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        odabirSimptoma.getItems().addAll(naziviSimptoma);
    }

    @FXML
    public void zapisiuDatoteku(){
        String naziv = nazivBolesti.getText();

        String odabraniSimptomi = "";

        simptomiHello = odabirSimptoma.getSelectionModel().getSelectedItems();

        for(Simptom h : listaSimptoma){
            for(String s : simptomiHello){
                if(s.equals(h.getNaziv()) && s.equals(simptomiHello.get(simptomiHello.size()-1))){
                    odabraniSimptomi+=h.getId();
                    break;
                }else if(s.equals(h.getNaziv())){
                    odabraniSimptomi+=h.getId()+",";
                    break;
                }
            }
        }

        List<Bolest> listaBolesti = PretragaBolestiController.getBolests(Glavna.getSimptoms());
        Long id = listaBolesti.get(listaBolesti.size()-1).getId() + 1;

        String ID = Long.toString(id);

        if(naziv.equals("") || odabraniSimptomi.equals("")){
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Zapis u datoteku");
            alert.setHeaderText("Greška u unosu podataka!");
            alert.setContentText("Ponovno unesite podatke!");
            alert.showAndWait();
        }else{
            try{
                Files.writeString(tekst, ID + '\n', StandardOpenOption.APPEND);
                Files.writeString(tekst, naziv + '\n', StandardOpenOption.APPEND);
                Files.writeString(tekst, odabraniSimptomi + '\n', StandardOpenOption.APPEND);
            }catch(IOException e){
                e.printStackTrace();
            }
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Zapis u datoteku");
            alert.setHeaderText("Uspješno zapisano!");
            alert.showAndWait();
        }
    }
}
