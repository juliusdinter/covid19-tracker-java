package main.java.sample;

import hr.java.covidportal.main.Glavna;
import hr.java.covidportal.model.Simptom;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.stream.Collectors;

public class PretragaSimptomaController implements Initializable {
    @FXML
    private TextField traziNazivSimptoma;

    @FXML
    private TextField traziVrijednostSimptoma;

    public static List<Simptom> simptomidat = Glavna.getSimptoms();

    @FXML
    private TableView<Simptom> tablicaSimptoma;

    @FXML
    private TableColumn<Simptom, String> stupacNaziva;

    @FXML
    private TableColumn<Simptom, String> vrijednostSimptoma;

    @FXML
    public void trazi(){
        String trazenaRijec = traziNazivSimptoma.getText();
        String trazenaVrijednost = traziVrijednostSimptoma.getText();
        List<Simptom> filtriranaListaSimptoma = simptomidat.stream()
                .filter(p -> p.getNaziv().toLowerCase().contains(trazenaRijec.toLowerCase())
                        && p.getVrijednost().toLowerCase().contains(trazenaVrijednost.toLowerCase()))
                .collect(Collectors.toList());
        tablicaSimptoma.setItems(FXCollections.observableList(filtriranaListaSimptoma));
    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        stupacNaziva.setCellValueFactory(new PropertyValueFactory<Simptom, String>("naziv"));
        vrijednostSimptoma.setCellValueFactory(new PropertyValueFactory<Simptom, String>("vrijednost"));
        tablicaSimptoma.setItems(FXCollections.observableList(simptomidat));
    }
}
