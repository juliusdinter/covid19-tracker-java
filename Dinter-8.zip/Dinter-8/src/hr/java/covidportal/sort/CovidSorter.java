package hr.java.covidportal.sort;

import hr.java.covidportal.model.Zupanija;

import java.util.Comparator;

public class CovidSorter implements Comparator<Zupanija> {
    @Override
    public int compare(Zupanija a, Zupanija b){
        if(((float)a.getBrojZarazenih()/a.getBrojStanovnika()*100)>((float)b.getBrojZarazenih()/b.getBrojStanovnika()*100)){
            return 1;
        }else if(((float)a.getBrojZarazenih()/a.getBrojStanovnika()*100)<((float)b.getBrojZarazenih()/b.getBrojStanovnika()*100)){
            return -1;
        }else{
            return 0;
        }
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        return super.equals(obj);
    }
}
