package hr.java.covidportal.genericsi;

import hr.java.covidportal.model.Osoba;
import hr.java.covidportal.model.Virus;

import java.util.EmptyStackException;
import java.util.List;

/**
 * Spremanje svih virusa i osoba zaraženih tim virusima
 * @param <T> extends Virus
 * @param <S> extends Osoba
 * @author Julius Dinter
 */
public class KlinikaZaInfektivneBolesti<T extends Virus, S extends Osoba> {
    private List<T> virusi;
    private List<S> osobeZarazeneVirusom;
    public KlinikaZaInfektivneBolesti(List<T> virusi, List<S> osobeZarazeneVirusom) {
        this.virusi = virusi;
        this.osobeZarazeneVirusom = osobeZarazeneVirusom;
    }
    public List<T> getVirusi() {
        return virusi;
    }

    public void setVirusi(List<T> virusi) {
        this.virusi = virusi;
    }

    public List<S> getOsobeZarazeneVirusom() {
        return osobeZarazeneVirusom;
    }

    public void setOsobeZarazeneVirusom(List<S> osobeZarazeneVirusom) {
        this.osobeZarazeneVirusom = osobeZarazeneVirusom;
    }
    public void Virusipush(T pushValue) {
        virusi.add(pushValue);
    }
    public T Virusipop()
    {
        if(virusi.isEmpty()) {
            throw new EmptyStackException();
        }
        return virusi.remove(virusi.size() -1);
    }
    public void Osobepush(S pushValue) {
        osobeZarazeneVirusom.add(pushValue);
    }
    public S Osobepop()
    {
        if(osobeZarazeneVirusom.isEmpty()) {
            throw new EmptyStackException();
        }
        return osobeZarazeneVirusom.remove(osobeZarazeneVirusom.size()-1);
    }

}
