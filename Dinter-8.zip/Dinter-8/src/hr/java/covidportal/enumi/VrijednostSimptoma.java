package hr.java.covidportal.enumi;

/**
 * Enumeracija za onemogućavanje upisa krivih vrijednosti! Moguće je upisati samo tri predložene!
 * @author Julius Dinter
 */
public enum VrijednostSimptoma {
    RIJETKO("RIJETKO"), SREDNJE("SREDNJE"), CESTO("ČESTO");
    private String vrijednost;
    VrijednostSimptoma(String vrijednost) {
        this.vrijednost = vrijednost;
    }

    public String getVrijednost() {
        return vrijednost;
    }

    public void setVrijednost(String vrijednost) {
        this.vrijednost = vrijednost;
    }
}
