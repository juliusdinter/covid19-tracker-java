package hr.java.covidportal.iznimke;

/**
 * Klasa koja služi kao iznimka bolesti sa istim simptomima
 * @author Julius Dinter
 */
public class BolestIstihSimptoma extends RuntimeException {
    public BolestIstihSimptoma(String message){
        super(message);
    }
    public BolestIstihSimptoma(Throwable cause){
        super(cause);
    }
    public BolestIstihSimptoma(String message, Throwable cause){
        super(message, cause);
    }
}
