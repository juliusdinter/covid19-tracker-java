package hr.java.covidportal.iznimke;

/**
 * Kontaktirane osobu moguće je odabrati samo jednom, ova klasa služi da se ista osoba ne može odabrati više od jednom
 * @author Julius Dinter
 */
public class DuplikatKontaktiraneOsobe extends Exception {
    public DuplikatKontaktiraneOsobe(String message){
        super(message);
    }
    public DuplikatKontaktiraneOsobe(Throwable cause){
        super(cause);
    }
    public DuplikatKontaktiraneOsobe(String message, Throwable cause){
        super(message, cause);
    }
}
