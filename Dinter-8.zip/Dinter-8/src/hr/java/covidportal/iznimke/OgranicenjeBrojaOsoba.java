package hr.java.covidportal.iznimke;

/**
 * Klasa koja služi kao iznimka prilikom odabira kontaktiranih osoba, moguće je odabrati samo osobe koje su prethodno navedene
 * @author Julius Dinter
 */
public class OgranicenjeBrojaOsoba extends Exception {
    public OgranicenjeBrojaOsoba(String message){
        super(message);
    }
    public OgranicenjeBrojaOsoba(Throwable cause){
        super(cause);
    }
    public OgranicenjeBrojaOsoba(String message, Throwable cause){
        super(message, cause);
    }
}
