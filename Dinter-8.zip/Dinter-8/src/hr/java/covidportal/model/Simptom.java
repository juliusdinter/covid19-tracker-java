package hr.java.covidportal.model;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Objects;

/**
 * Klasa Simptom
 * @author Julius Dinter
 * @version
 */

public class Simptom extends ImenovaniEntitet implements Serializable {
    private String vrijednost;
    private Long id;

    public Simptom(Long id, String naziv, String vrijednost) {
        super(naziv, id);
        this.vrijednost = vrijednost;
        this.id = id;
    }

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public String getNaziv() {
        return naziv;
    }
    @Override
    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public String getVrijednost() {
        return vrijednost;
    }

    public void setVrijednost(String vrijednost) {
        this.vrijednost = vrijednost;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Simptom)) return false;
        if (!super.equals(o)) return false;
        Simptom simptom = (Simptom) o;
        return Objects.equals(getVrijednost(), simptom.getVrijednost());
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), getVrijednost());
    }

    @Override
    public String toString() {
        return getNaziv();
    }
}
