package hr.java.covidportal.model;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

/**
 * Klasa Osoba
 * @author Julius Dinter
 * @version
 */
public class Osoba implements Serializable {
    private Long id;
    private String ime;
    private String prezime;
    private Long starost;
    private Zupanija zupanija;
    private Bolest zarazenBolescu;
    private List<Osoba> kontaktiraneOsobe;

    public Osoba(Long id, String ime, String prezime, Long starost, Zupanija zupanija,
                 Bolest zarazenBolescu, List<Osoba> kontaktiraneOsobe) {
        this.id = id;
        this.ime = ime;
        this.prezime = prezime;
        this.starost = starost;
        this.zupanija = zupanija;
        this.zarazenBolescu = zarazenBolescu;
        this.kontaktiraneOsobe = kontaktiraneOsobe;
        if(this.zarazenBolescu instanceof Virus virus){
            if(this.kontaktiraneOsobe!=null){
                for (Osoba osoba : this.kontaktiraneOsobe) {
                    if(osoba!=null){
                        osoba.setZarazenBolescu(virus);
                    }
                }
            }
        }
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public void setPrezime(String prezime) {
        this.prezime = prezime;
    }

    public Long getStarost() {
        return starost;
    }

    public void setStarost(Long starost) {
        this.starost = starost;
    }

    public Zupanija getZupanija() {
        return zupanija;
    }

    public void setZupanija(Zupanija zupanija) {
        this.zupanija = zupanija;
    }

    public Bolest getZarazenBolescu() {
        return zarazenBolescu;
    }

    public void setZarazenBolescu(Bolest zarazenBolescu) {
        this.zarazenBolescu = zarazenBolescu;
    }

    public List<Osoba> getKontaktiraneOsobe() {
        return kontaktiraneOsobe;
    }

    public void setKontaktiraneOsobe(List<Osoba> kontaktiraneOsobe) {
        this.kontaktiraneOsobe = kontaktiraneOsobe;
    }

    @Override
    public String toString() {
        return getIme() + " " + getPrezime();
    }
}
