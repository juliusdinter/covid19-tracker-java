package hr.java.covidportal.model;

import java.io.Serializable;
import java.util.Arrays;
import java.util.List;

/**
 * Klasa Bolest
 * @author Julius Dinter
 * @version
 */
public class Bolest extends ImenovaniEntitet implements Serializable {
    private List<Simptom> simptomi;
    private Long id;

    public Bolest(Long id, String naziv, List<Simptom> simptomi) {
        super(naziv, id);
        this.simptomi = simptomi;
        this.id = id;
    }

    public int getIdBolesti() {
        return 1;
    }

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    /**
     * Metoda za dobivanje naziva bolesti
     * @return vraća naziv bolesti
     */
    @Override
    public String getNaziv() {
        return naziv;
    }

    /**
     * Metoda za postavljanje naziva bolesti
     * @param naziv
     */
    @Override
    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    /**
     * Metoda za dobivanje simptoma pojedine bolesti
     * @return vraća simptome bolesti
     */
    public List<Simptom> getSimptomi() {
        return simptomi;
    }

    /**
     * Metoda za postavljanje simptoma bolesti
     * @param simptomi
     */
    public void setSimptomi(List<Simptom> simptomi) {
        this.simptomi = simptomi;
    }

    @Override
    public String toString() {
        return getNaziv();
    }
}
