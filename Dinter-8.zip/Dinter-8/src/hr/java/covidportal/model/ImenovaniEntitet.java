package hr.java.covidportal.model;

import java.io.Serializable;
import java.util.Objects;

/**
 * Apstraktna klasa sa nasljeđivanjem metoda getNaziv() i setNaziv()
 * @author Julius Dinter
 */

public abstract class ImenovaniEntitet implements Serializable {
    protected String naziv;
    private Long id;

    public ImenovaniEntitet(String naziv, Long id) {
        this.naziv = naziv;
        this.id = id;
    }

    public abstract Long getId();

    public abstract void setId(Long id);

    public abstract String getNaziv();
    public abstract void setNaziv(String naziv);

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof ImenovaniEntitet)) return false;
        ImenovaniEntitet that = (ImenovaniEntitet) o;
        return Objects.equals(getNaziv(), that.getNaziv());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getNaziv());
    }
}
