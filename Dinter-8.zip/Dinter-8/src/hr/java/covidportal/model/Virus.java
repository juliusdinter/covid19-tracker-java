package hr.java.covidportal.model;

import java.io.Serializable;
import java.util.List;

/**
 * Klasa Virus
 * @author Julius Dinter
 */

public class Virus extends Bolest implements Zarazno, Serializable {
    private Long id;

    public Virus(Long id, String naziv, List<Simptom> Simptomi) {
        super(id, naziv, Simptomi);
        this.id = id;
    }

    public int getIdBolesti() {
        return 2;
    }

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public void prelazakZarazeNaOsobu(Osoba o){
        o.setZarazenBolescu(this);
    }

    @Override
    public boolean equals(Object o) {
        return super.equals(o);
    }

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public String toString() {
        return getNaziv();
    }
}
