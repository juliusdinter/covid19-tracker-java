package hr.java.covidportal.model;

/**
 * Sučelje Zarazno
 * @author Julius Dinter
 * @version
 */

public interface Zarazno {
    void prelazakZarazeNaOsobu(Osoba o);
}
