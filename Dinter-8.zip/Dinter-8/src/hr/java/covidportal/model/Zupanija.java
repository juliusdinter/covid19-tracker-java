package hr.java.covidportal.model;

import java.io.Serializable;
import java.util.Objects;

/**
 * Klasa Zupanija
 * @author Julius Dinter
 * @version
 */

public class Zupanija extends ImenovaniEntitet implements Serializable {
    private Integer brojStanovnika;
    private Integer brojZarazenih;
    private Long id;
    public Integer getBrojZarazenih() {
        return brojZarazenih;
    }

    public void setBrojZarazenih(Integer brojZarazenih) {
        this.brojZarazenih = brojZarazenih;
    }

    public Zupanija(Long id, String naziv, Integer brojStanovnika, Integer brojZarazenih) {
        super(naziv, id);
        this.brojStanovnika = brojStanovnika;
        this.brojZarazenih = brojZarazenih;
        this.id = id;
    }

    @Override
    public Long getId() {
        return id;
    }

    @Override
    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public String getNaziv() {
        return naziv;
    }
    @Override
    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public Integer getBrojStanovnika() {
        return brojStanovnika;
    }

    public void setBrojStanovnika(Integer brojStanovnika) {
        this.brojStanovnika = brojStanovnika;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Zupanija)) return false;
        if (!super.equals(o)) return false;
        Zupanija zupanija = (Zupanija) o;
        return Objects.equals(getBrojStanovnika(), zupanija.getBrojStanovnika()) &&
                Objects.equals(getBrojZarazenih(), zupanija.getBrojZarazenih());
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), getBrojStanovnika(), getBrojZarazenih());
    }

    @Override
    public String toString() {
        return getNaziv();
    }
}
