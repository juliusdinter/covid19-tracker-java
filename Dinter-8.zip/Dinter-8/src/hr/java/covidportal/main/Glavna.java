package hr.java.covidportal.main;

import hr.java.covidportal.genericsi.KlinikaZaInfektivneBolesti;
import hr.java.covidportal.model.*;
import hr.java.covidportal.sort.CovidSorter;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.time.Duration;
import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;
/**
 * Glavna klasa sa svim funkcionalnostima i metodama
 * @author Julius Dinter
 */

public class Glavna {
    private static final Logger logger = LoggerFactory.getLogger(Glavna. class);
    public static void main(String[] args) throws IOException {
        Scanner tipkovnica = new Scanner(System.in);
        System.out.println("Učitavanje podataka o županijama...");
        List<Zupanija> zupanijeList = getZupanijas();
        System.out.println("Učitavanje podataka o simptomima...");
        List<Simptom> simptomiList = getSimptoms();
        System.out.println("Učitavanje podataka o bolestima...");
        List<Bolest> bolestiList = getBolests(simptomiList);
        System.out.println("Učitavanje podataka o virusima...");
        File virusi = new File("dat/virusi.txt");
        try(FileReader fileReader = new FileReader(virusi);
            BufferedReader reader = new BufferedReader(fileReader)){
            String procitanaLinija;
            while((procitanaLinija = reader.readLine())!=null){
                int brojacBolesti=0;
                Long id = Long.parseLong(procitanaLinija);
                String naziv = reader.readLine();
                String brojevi = reader.readLine();
                List<Long> idSimptoma = new ArrayList<>();
                for(int i=0;i<brojevi.length();i++){
                    if(brojevi.charAt(i)!=','){
                        int broj=Character.getNumericValue(brojevi.charAt(i));
                        idSimptoma.add((long) broj);
                        brojacBolesti++;
                    }
                }
                bolestiList.add(new Virus(id, naziv, dodaj(idSimptoma, simptomiList)));
            }
        }
        catch (IOException ex){
            ex.printStackTrace();
        }
        System.out.println("Učitavanje osoba...");
        List<Osoba> osobeList = getOsobas(zupanijeList, bolestiList);
        System.out.println("Popis osoba: ");
        for(int i=0;i<osobeList.size();i++){
            popisOsoba(osobeList, i);
        }
        Map<Bolest, List<Osoba>> mapaBolesti = new HashMap<>();
        // provjeravanja od koje bolesti boluje osoba i spremanje u mapu, spremanje svih virusa u listu
        List<Virus> sviVirusi = new ArrayList<>();
        List<Osoba> osobeZarazeneVirusima = new ArrayList<>();
        for(int i=0;i<bolestiList.size();i++){
            List<Osoba> osobeZarazeneBolescu = new ArrayList<>();
            if(bolestiList.get(i) instanceof Virus){
                sviVirusi.add((Virus) bolestiList.get(i));
            }
            for(int j=0;j<osobeList.size();j++){
                if(bolestiList.get(i).equals(osobeList.get(j).getZarazenBolescu())){
                    osobeZarazeneBolescu.add(osobeList.get(j));
                    if(bolestiList.get(i) instanceof Virus){
                        osobeZarazeneVirusima.add(osobeList.get(j));
                    }
                }
            }
            mapaBolesti.put(bolestiList.get(i), osobeZarazeneBolescu);
        }
        for(Bolest key : mapaBolesti.keySet() ) {
            if (!mapaBolesti.get(key).isEmpty()) {
                if (key instanceof Virus) {
                    System.out.print("Od virusa " + key.getNaziv() + " boluju: ");
                } else {
                    System.out.println("Od bolesti " + key.getNaziv() + " boluju: ");
                }
                List<Osoba> osobeIspis;
                osobeIspis = mapaBolesti.get(key);
                for (int i = 0; i < osobeIspis.size(); i++) {
                    if (i != osobeIspis.size() - 1) {
                        System.out.print(osobeIspis.get(i).getIme() + " " + osobeIspis.get(i).getPrezime() + ", ");
                    } else {
                        System.out.print(osobeIspis.get(i).getIme() + " " + osobeIspis.get(i).getPrezime());
                        System.out.println();
                    }
                }
            }
        }
        zupanijeList.sort(new CovidSorter());
        System.out.println("Najviše zaraženih osoba ima u županiji " + zupanijeList.get(zupanijeList.size()-1).getNaziv() + ": "
                + (int)((float)zupanijeList.get(zupanijeList.size()-1).getBrojZarazenih()/zupanijeList.get(zupanijeList.size()-1).getBrojStanovnika()*100) + "%.");
//         Sortiranje virusa spremljenih u kliniku (bolnicu) pomoću lambde
        KlinikaZaInfektivneBolesti<Virus, Osoba> bolnica = new KlinikaZaInfektivneBolesti<>(sviVirusi, osobeZarazeneVirusima);
        System.out.println("Virusi sortirani po nazivu suprotno od poretka abecede: ");
        Instant start1 = Instant.now();
        int brojilo=0;
        List<Virus> virusiLista = bolnica.getVirusi().stream().sorted(Comparator.comparing(Virus::getNaziv).reversed()).collect(Collectors.toList());
        for(Virus v : virusiLista){
            brojilo++;
            System.out.println(brojilo + ". " + v);
        }
        Instant end1 = Instant.now();
        // Sortiranje bez lambde
        Instant start2 = Instant.now();
        Comparator<Virus> VirusComparator
                = new Comparator<Virus>() {

            public int compare(Virus virus1, Virus virus2) {

                String naziv1 = virus1.getNaziv();
                String naziv2 = virus2.getNaziv();
                if(naziv1.compareTo(naziv2)!=0){
                    return naziv1.compareTo(naziv2);
                }else{
                    return naziv2.compareTo(naziv1);
                }
            }
        };
        bolnica.getVirusi().sort(VirusComparator);
        Instant end2 = Instant.now();
        System.out.println("Sortiranje objekata korištenjem lambdi traje " + Duration.between(start1, end1).toMillis() +
                " milisekundi, a bez lambde traje " + Duration.between(start2, end2).toMillis() + " milisekundi." );
        // Pretraga prezimena za unesen string
        System.out.print("Unesite string za pretragu po prezimenu: ");
        String pretraga = tipkovnica.nextLine();
        Optional<List<Osoba>> osobePretraga = Optional.of(osobeList.stream().filter(osoba -> osoba.getPrezime().contains(pretraga)).collect(Collectors.toList()));
        System.out.println("Osobe čije prezime sadrži \"" + pretraga + "\" su sljedeće: " );
        if(osobePretraga.get().isEmpty()){
            System.out.println("Nema takvih osoba!");
        }else{
            osobePretraga.get().forEach(System.out::println);
        }
        // Broj simptoma za svaku bolest pomoću map()
        List<Integer> brojSimptomaZaSvakuBolest;
        brojSimptomaZaSvakuBolest = bolestiList.stream().map(bolest -> bolest.getSimptomi().size()).collect(Collectors.toList());
        brojilo=0;
        for(int br : brojSimptomaZaSvakuBolest){
            System.out.println(bolestiList.get(brojilo).getNaziv() + " ima " + br + " simptoma." );
            brojilo++;
        }
        try(ObjectOutputStream serializator = new ObjectOutputStream(new FileOutputStream("dat/serijalizirani.dat"))){
            List<Zupanija> zupanijas;
            zupanijas=zupanijeList.stream().filter(p -> ((int)(((float)p.getBrojZarazenih() / p.getBrojStanovnika())*100))>=2).collect(Collectors.toList());
            serializator.writeObject(zupanijas);

        }catch(IOException ex){
            ex.printStackTrace();
        }
        File file = new File("dat/serijalizirani.dat");
        try(ObjectInputStream in = new ObjectInputStream(new FileInputStream(file))){
            List<Zupanija> procitaneZupanije= (List<Zupanija>) in.readObject();
            System.out.println("Deserijalizirane zupanije: ");
            for(Zupanija zupanija : procitaneZupanije){
                System.out.println(zupanija);
            }
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    public static List<Osoba> getOsobas(List<Zupanija> zupanijeList, List<Bolest> bolestiList) {
        List<Osoba> osobeList = new ArrayList<>();
        File osobe = new File("dat/osobe.txt");
        int brojacOsoba = 0;
        try(FileReader fileReader = new FileReader(osobe);
            BufferedReader reader = new BufferedReader(fileReader)){
            String procitanaLinija;
            while((procitanaLinija= reader.readLine())!=null){
                Long id = Long.parseLong(procitanaLinija);
                String ime = reader.readLine();
                String prezime = reader.readLine();
                Long starost = Long.parseLong(reader.readLine());
                Long odabirZupanije = Long.parseLong(reader.readLine());
                String odabirBolesti = reader.readLine();
                List<Integer> idBolesti=new ArrayList<>();
                for(int i=0;i<odabirBolesti.length();i++){
                    if(odabirBolesti.charAt(i)!=','){
                        int broj=Character.getNumericValue(odabirBolesti.charAt(i));
                        idBolesti.add(broj);
                    }
                }
                String odabirOsoba = reader.readLine();
                List<Long> idKontakata = new ArrayList<>();
                for(int i=0;i<odabirOsoba.length();i++){
                    if(odabirOsoba.charAt(i)!=','){
                        int broj=Character.getNumericValue(odabirOsoba.charAt(i));
                        idKontakata.add((long) broj);
                    }
                }
                if(brojacOsoba==0){
                    osobeList.add(new Osoba(id, ime, prezime, starost,
                            dodajZupaniju(odabirZupanije, zupanijeList),
                            dodajBolest(idBolesti, bolestiList), null));
                }else{
                    osobeList.add(new Osoba(id, ime, prezime, starost,
                            dodajZupaniju(odabirZupanije, zupanijeList),
                            dodajBolest(idBolesti, bolestiList), dodajKontakte(idKontakata, osobeList)));
                }
                brojacOsoba++;
            }
        }
        catch (IOException ex){
            ex.printStackTrace();
        }
        return osobeList;
    }

    public static List<Bolest> getBolests(List<Simptom> simptomiList) {
        List<Bolest> bolestiList = new ArrayList<>();
        File bolesti = new File("dat/bolesti.txt");
        try(FileReader fileReader = new FileReader(bolesti);
            BufferedReader reader = new BufferedReader(fileReader)){
            String procitanaLinija;
            while((procitanaLinija = reader.readLine())!=null){
                int brojacBolesti=0;
                Long id = Long.parseLong(procitanaLinija);
                String naziv = reader.readLine();
                String brojevi = reader.readLine();
                List<Long> idSimptoma = new ArrayList<>();
                for(int i=0;i<brojevi.length();i++){
                    if(brojevi.charAt(i)!=','){
                        int broj=Character.getNumericValue(brojevi.charAt(i));
                        idSimptoma.add((long) broj);
                        brojacBolesti++;
                    }
                }
                bolestiList.add(new Bolest(id, naziv, dodaj(idSimptoma, simptomiList)));
            }
        }
        catch (IOException ex){
            ex.printStackTrace();
        }
        return bolestiList;
    }

    public static List<Simptom> getSimptoms() {
        List<Simptom> simptomiList = new ArrayList<>();
        File simptomi = new File("dat/simptomi.txt");
        try(FileReader fileReader = new FileReader(simptomi);
            BufferedReader reader = new BufferedReader(fileReader)){
            String procitanaLinija;
            while((procitanaLinija= reader.readLine())!=null){
                Long id = Long.parseLong(procitanaLinija);
                String naziv = reader.readLine();
                String vrijednostSimptoma = reader.readLine();
                simptomiList.add(new Simptom(id, naziv, vrijednostSimptoma));
            }
        }
        catch (IOException ex){
            ex.printStackTrace();
        }
        return simptomiList;
    }

    public static List<Zupanija> getZupanijas() {
        List<Zupanija> zupanijeList = new ArrayList<>();
        File zupanije = new File("dat/zupanije.txt");
        try(FileReader fileReader = new FileReader(zupanije);
            BufferedReader reader = new BufferedReader(fileReader)){
            String procitanaLinija;
            while((procitanaLinija= reader.readLine())!=null){
                Long id = Long.parseLong(procitanaLinija);
                String naziv = reader.readLine();
                Integer brojStanovnika = Integer.parseInt(reader.readLine());
                Integer brojZarazenih = Integer.parseInt(reader.readLine());
                zupanijeList.add(new Zupanija(id, naziv, brojStanovnika, brojZarazenih));
            }
        }
        catch (IOException ex){
            ex.printStackTrace();
        }
        return zupanijeList;
    }

    private static void popisOsoba(List<Osoba> osobe, int i) {
        System.out.println("Ime i prezime: " + osobe.get(i).getIme() + " " + osobe.get(i).getPrezime());
        System.out.println("Starost: " + osobe.get(i).getStarost());
        Zupanija zupanijaPrebivalista= osobe.get(i).getZupanija();
        System.out.println("Županija prebivališta: "+ zupanijaPrebivalista.getNaziv());
        Bolest zarazenBolescu= osobe.get(i).getZarazenBolescu();
        System.out.println("Zaražen bolešću: " + zarazenBolescu.getNaziv());
        List<Osoba> kontaktOsobe= osobe.get(i).getKontaktiraneOsobe();
        System.out.println("Kontaktirane osobe: ");
        if(osobe.get(i).getKontaktiraneOsobe()==null){
            System.out.println("Nema kontaktiranih osoba.");
        }else{
            for(int j = 0; j < i; j++){
                if(kontaktOsobe.get(j)!=null){
                    System.out.println(kontaktOsobe.get(j).getIme() + " " + kontaktOsobe.get(j).getPrezime());
                }
            }
        }
    }

    private static List<Osoba> dodajKontakte(List<Long> idKontakata, List<Osoba> osobeList) {
        List<Osoba> kontaktiOsoba = new ArrayList<>();
        for (Long aLong : idKontakata) {
            if (aLong != null) {
                for (Osoba osoba : osobeList) {
                    if (aLong.equals(osoba.getId())) {
                        kontaktiOsoba.add(osoba);
                    }
                }
            }
        }
        return kontaktiOsoba;
    }

    private static Bolest dodajBolest(List<Integer> odabirBolesti, List<Bolest> bolestiList) {
        if(odabirBolesti.get(1).equals(1)){
            for(int i=0;i<bolestiList.size();i++){
                if(bolestiList.get(i).getId().equals((long)odabirBolesti.get(0))){
                    return bolestiList.get(i);
                }
            }
        }else if(odabirBolesti.get(1).equals(2)){
            List<Virus> listaVirusa = new ArrayList<>();
            for(int i=0;i<bolestiList.size();i++){
                if(bolestiList.get(i) instanceof Virus){
                    listaVirusa.add((Virus) bolestiList.get(i));
                }
            }
            for(int i=0;i<listaVirusa.size();i++){
                if(listaVirusa.get(i).getId().equals((long)odabirBolesti.get(0))){
                    return listaVirusa.get(i);
                }
            }
        }
        return null;
    }

    private static Zupanija dodajZupaniju(Long odabirZupanije, List<Zupanija> zupanijeList) {
        return zupanijeList
                .stream()
                .filter(p -> odabirZupanije.equals(p.getId()))
                .findAny()
                .orElse(null);
    }

    private static List<Simptom> dodaj(List<Long> idSimptoma, List<Simptom> simptomiList) {
        List<Simptom> simptomiBolesti= new ArrayList<>();
        for(int i=0; i<idSimptoma.size(); i++){
            if(idSimptoma.get(i)!=null){
                for(int j=0;j<simptomiList.size();j++){
                    if(idSimptoma.get(i).equals(simptomiList.get(j).getId())){
                        simptomiBolesti.add(new Simptom(simptomiList.get(j).getId(), simptomiList.get(j).getNaziv(), simptomiList.get(j).getVrijednost()));
                    }
                }
            }
        }
        return simptomiBolesti;
    }
}
